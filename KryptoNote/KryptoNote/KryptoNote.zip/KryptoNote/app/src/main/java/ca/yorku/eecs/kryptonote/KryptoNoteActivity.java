package ca.yorku.eecs.kryptonote;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;

public class KryptoNoteActivity extends AppCompatActivity
{
    public void onSave(View v)
    {
        try
        {
            String name = ((EditText)findViewById(R.id.file)).getText().toString();
            File dir = this.getFilesDir();
            File file = new File(dir,name);
            FileWriter fw = new FileWriter(file);
            fw.write(((EditText)findViewById(R.id.data)).getText().toString());
            fw.close();
            Toast.makeText(this, "Note Saved", Toast.LENGTH_SHORT);

        }
        catch(Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
