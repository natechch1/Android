package com.example.caps;
//Student Name: Shuyi shi

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class CapsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.caps_layout);
        initialize();
    }
    private Game game;
    private String question;
    private String answer;
    private int score;
    private int qNum;
    private ScrollView sv;
    private LinearLayout output;
    private TextView tv;
    private String log = "";
    private String previousLog = "";

    private void initialize()
    {
        sv = findViewById(R.id.sv);
        sv.removeAllViews();
        output = new LinearLayout(this);
        output.setOrientation(LinearLayout.VERTICAL);
        sv.addView(output);
        tv = new TextView(this);
        tv.setGravity(Gravity.LEFT);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
        tv.setTypeface(null, Typeface.NORMAL);
        output.addView(tv);
        qNum = 1;
        score = 0;
        ((TextView) findViewById(R.id.score)).setText("SCORE = " + score);
        ((TextView) findViewById(R.id.qNum)).setText("Q# " + qNum);
        ask();
    }
    private void ask()
    {
        game = new Game();
        String [] s = game.qa().split("\n");
        question = s[0];
        answer = s[1];
        ((TextView) findViewById(R.id.question)).setText(question);
    }

    public void onDone(View v)
    {
        String userInput = ((EditText) findViewById(R.id.answer)).getText().toString();
        String upperCaseInput = userInput.toUpperCase();
        if (!upperCaseInput.equalsIgnoreCase(""))
        {
            if (upperCaseInput.equalsIgnoreCase(answer))
            {
                score++;
                ((TextView) findViewById(R.id.score)).setText("SCORE = " + score);
            }
            log = "Q# " + qNum + ": " + question + "\n" + "Your answer: " + upperCaseInput + "\n" + "Correct answer: " + answer + "\n\n";
            tv.setText(log + previousLog);
            previousLog = log + previousLog;
            qNum++;

            if (qNum >= 10)
            {
                ((TextView) findViewById(R.id.qNum)).setText("GAME OVER!");
                findViewById(R.id.done).setEnabled(false);
            }
            else
            {
                ((TextView) findViewById(R.id.qNum)).setText("Q# " + qNum);
                ask();
            }

            ((EditText) findViewById(R.id.answer)).setText("");
        }
    }
}
